package com.example.myfinalpro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Activity6 extends AppCompatActivity {
    public Button button8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_6);
        button8 = (Button) findViewById(R.id.button8);
        button8.setOnClickListener(new View.OnClickListener()  {
            @Override
            public void onClick(View v) {
                MainActivity();
            }
        });
    }

    public void MainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

    }
}